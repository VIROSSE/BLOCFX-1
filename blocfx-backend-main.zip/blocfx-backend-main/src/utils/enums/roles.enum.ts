export enum Role {
  ADMIN = 'admin',
  NORMAL = 'normal',
}
