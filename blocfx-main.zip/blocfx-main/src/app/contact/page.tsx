import React from 'react'
import GetInTouch from '../components/fastPay/contanct'

export default function ContactPage() {
    return (
        <div>
            <div className=' h-20 bg-black w-full  text-white absolute top-0 -z-20' />
            <GetInTouch />
        </div>
    )
}
